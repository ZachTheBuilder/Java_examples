//Author Zachariah Rosson
public class RecursionFun {

	// 1
	// in this method we will be combining n with k and previous k
	public int combinations(int n, int k) {
		if (n == 0)
			return 0;

		if (k == 1)
			return n;
		else if (n == k)
			return 1;
		else
			return combinations(n - 1, k - 1) + combinations(n - 1, k);
	}

	// 2
	// in this method we will be taking n and multiplying it by the next n
	public int factorial(int n) {
		if (n <= 1)
			return 1;
		return n * factorial(n - 1);
	}

	// 3
	// in this method we will be taking n divided by n plus the next n to get
	// the reciprocals
	public double addReciprocals(double n) {
		if (n < 0)
			return 0;
		if (n == 0)
			return 0;

		return (1.0 / n) + addReciprocals(n - 1);
	}

	// 4
	// in this method we will be find the greatest common denominator
	public int GCD(int m, int n) {
		if (m < 0 || n < 0 || m == 0 && n == 0)
			return 0;
		if (m == 0)
			return n;
		if (n == 0)
			return m;

		return GCD(n, m % n);
	}

	// 5
	// in this method we will be taking the sum of the two prev number to get
	// our answer
	public int fibonacci(int n) {
		if (n <= 0 || n > 40)
			return 0;
		else if (n == 1)
			return 1;
		else
			return fibonacci(n - 1) + fibonacci(n - 2);
	}

	// 6
	// in this method we will be adding an underscore between all duplicate
	// chars in the string
	public String underScore(String str) {
		if (str.equals("") || str.length() == 1)
			return str;

		if (str.charAt(0) == str.charAt(1))
			return str.charAt(0) + "_" + underScore(str.substring(1));
		else
			return str.charAt(0) + underScore(str.substring(1));
	}

	// 7
	// in this method we will be checking to see if there are nested parentheses
	// or not with nothing else
	public boolean nestParen(String str) {
		if (str.equals(""))
			return true;

		if (str.charAt(0) == '(' && str.charAt(str.length() - 1) == ')')
			return nestParen(str.substring(1, str.length() - 1));
		else
			return false;
	}

	// 8
	// in this method we will be deleting all duplicates
	public String noAdjacents(String str) {
		if (str.length() < 2)
			return str;

		if (str.charAt(0) == str.charAt(1))
			return noAdjacents(str.substring(1));
		else
			return str.charAt(0) + noAdjacents(str.substring(1));
	}

	// 9
	// in this method we will be converting all the numbers passed by the bases
	// passed
	public String convert(int num, int base) {
		if (num == 0)
			return "";

		return convert(num / base, base) + (num % base);
	}

	// 10
	// in this method we will be adding commas to the passed number to read like
	// this 1,890,888
	@SuppressWarnings("static-access")
	public String intWithCommas(int n) {
		if (n == 0)
			return "" + n;

		String num = "" + n;
		if (num.length() < 4)
			return num;

		return num.format("%,d", n);
	}

	// 11
	// in this method we will be finding the sum of the array between two givn
	// points
	public int sumArray(int[] nums, int beginIndex, int endIndex) {

		if (beginIndex > endIndex)
			return 0;
		if (beginIndex == endIndex)
			return nums[beginIndex];
		else {
			int n = nums[beginIndex];
			return n + sumArray(nums, beginIndex + 1, endIndex);
		}
	}

	// 12
	// in this method we will be finding the sum of the whole array
	public int sumArray(int[] nums) {
		return sumArray(nums, 0, nums.length - 1);
	}

	// 13__________________________________________________
	// in this method we will be we will be reversing the given array
	public void reverseArray(int[] nums) {
		reverse(nums, 0, nums.length - 1);
	}

	// helper method to swap elements
	public int[] reverse(int[] array, int first, int last) {
		int temp = 0;

		if (first < last) {
			temp = array[first];
			array[first] = array[last];
			array[last] = temp;
			return reverse(array, first + 1, last - 1);
		} else
			return array;
	}

	// ----------------------------------------------------
	// 14___________________________________________________
	// in this method we will be finding the max and minus it on the min
	public int arrayRange(int[] nums) {
		return getMax(nums, 0, nums.length - 1) - getMin(nums, 0, nums.length - 1);
	}

	// check length and index of min
	// helper to find max
	public int getMax(int[] nums, int first, int last) {

		if (first == last)
			return nums[first];
		else if (nums[first] < nums[last])
			return getMax(nums, first + 1, last);
		else
			return nums[first];
	}

	// helper to find min
	public int getMin(int[] nums, int first, int last) {

		if (first == last)
			return nums[first];
		else if (nums[first] > nums[last])
			return getMin(nums, first + 1, last);
		else
			return nums[first];
	}

	// ------------------------------------------------------------
	// 15________________________________________________
	// in this method we will be checking to see if the given array is sorted
	public boolean isSorted(int[] nums) {
		return checkSorted(nums, nums.length);
	}

	// helper method to check if it is sorted
	public static boolean checkSorted(int[] nums, int n) {

		if (nums == null || n < 2) {
			return true;
		} else if (nums[n - 2] > nums[n - 1]) {
			return false;
		}
		return checkSorted(nums, n - 1);
	}

	// ------------------------------------------
	// 16________________________________________
	// in this method we will be checking an array for the given word
	public boolean found(String search, String[] strs) {

		return getFound(search, strs, 0);
	}

	// helper method to find if word is in array
	public boolean getFound(String search, String[] strs, int start) {
		if (start >= strs.length)
			return false;

		if (strs[start] == search)
			return true;
		else
			return getFound(search, strs, start + 1);
	}

	// ---------------------------------------------
	// 17_________________________________________________
	// in this method we will be return the index of where the word was found in
	// the array
	public int binarySearch(String searchValue, String[] strs) {
		return getBinarySearch(searchValue, strs, 0);
	}

	// helper method to find the word
	public int getBinarySearch(String search, String[] strs, int start) {
		if (start >= strs.length)
			return -1;

		if (strs[start] == search)
			return start;
		else
			return getBinarySearch(search, strs, start + 1);
	}

	// --------------------------------------------------

}
