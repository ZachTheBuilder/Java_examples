import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

//Author Zachariah Rosson
public class RecursionFunTest {

	RecursionFun rf = new RecursionFun();

	// 2
	@Test
	public void combinations() {
		assertEquals(10, rf.combinations(10, 1));
		assertEquals(1, rf.combinations(1, 1));
		assertEquals(35, rf.combinations(7, 3));
	}

	// 2
	@Test
	public void factorial() {
		assertEquals(1, rf.factorial(0));
		assertEquals(1, rf.factorial(1));
		assertEquals(2, rf.factorial(2));
		assertEquals(6, rf.factorial(3));
		assertEquals(24, rf.factorial(4));
	}

	// 3
	@Test
	public void addReciprocalsTest() {
		assertEquals(1.0, rf.addReciprocals(1), .9);
		assertEquals(1.5, rf.addReciprocals(2), .9);
		assertEquals(1.83333333333333, rf.addReciprocals(3), .9);
	}

	// 4
	@Test
	public void GCDTest() {
		assertEquals(3, rf.GCD(24, 9));
		assertEquals(10, rf.GCD(50, 20));
		assertEquals(1, rf.GCD(7, 20));
	}

	// 5
	@Test
	public void fibonacciTest() {
		assertEquals(1, rf.fibonacci(1));
		assertEquals(1, rf.fibonacci(2));
		assertEquals(2, rf.fibonacci(3));
		assertEquals(3, rf.fibonacci(4));
		assertEquals(5, rf.fibonacci(5));
		assertEquals(8, rf.fibonacci(6));
	}

	// 6
	@Test
	public void underScoreTest() {
		assertEquals("hel_lo", rf.underScore("hello"));
		assertEquals("x_xy_y", rf.underScore("xxyy"));
		assertEquals("a_a_a_a", rf.underScore("aaaa"));
	}

	// 7
	@Test
	public void nestParenTest() {
		assertTrue(rf.nestParen("(())"));
		assertTrue(rf.nestParen("((()))"));
		assertFalse(rf.nestParen("((())"));
		assertFalse(rf.nestParen("("));
		assertFalse(rf.nestParen("(x"));
		assertFalse(rf.nestParen("x)"));
		assertFalse(rf.nestParen("(yy)"));
	}

	// 8
	@Test
	public void noAdjacentsTest() {
		assertEquals("yza", rf.noAdjacents("yyzzza"));
		assertEquals("abcd", rf.noAdjacents("abbbcd"));
		assertEquals("Helo", rf.noAdjacents("Hello"));
	}

	// 9
	@Test
	public void convertTest() {
		assertEquals("1", rf.convert(1, 2));
		assertEquals("11", rf.convert(3, 2));
		assertEquals("101", rf.convert(5, 2));
		assertEquals("15", rf.convert(13, 8));
		assertEquals("10", rf.convert(8, 8));
		assertEquals("123", rf.convert(123, 10));
	}

	// 10
	@Test
	public void intWithCommasTest() {
		assertEquals("999", rf.intWithCommas(999));
		assertEquals("1,234", rf.intWithCommas(1234));
		assertEquals("1,007", rf.intWithCommas(1007));
		assertEquals("1,023,004,567", rf.intWithCommas(1023004567));
	}

	// 11
	@Test
	public void sumArrayTest() {
		int[] nums = { 3, 4, 5, 1, 5, 9, 0 };

		assertEquals(13, rf.sumArray(nums, 0, 3));

	}

	// 12
	@Test
	public void sumAllArrayTest() {
		int[] nums = { 3, 4, 5, 1 };

		assertEquals(13, rf.sumArray(nums));

	}

	// 13
	@Test
	public void reverseArrayTest() {
		int[] a = { 2, 4, 6 };
		rf.reverseArray(a);
		assertEquals(6, a[0]);
		assertEquals(4, a[1]);
		assertEquals(2, a[2]);
	}

	// 14
	@Test
	public void arrayRangeTest() {
		assertEquals(2, rf.arrayRange(new int[] { 1, 2, 3 }));
		assertEquals(2, rf.arrayRange(new int[] { 3, 2, 1 }));
		assertEquals(0, rf.arrayRange(new int[] { 3 }));
		//assertEquals(3, rf.arrayRange(new int[] { -3, -2, -5, -4 }));

	}

	// 15
	@Test
	public void isSortedTest() {
		int[] one = { 1, 2, 3, 4, 5 };
		int[] two = { 1, 2, 3, 4, 5 };
		int[] three = { 1, 2, 4, 5, 3 };

		assertTrue(rf.isSorted(one));
		assertTrue(rf.isSorted(two));
		assertFalse(rf.isSorted(three));
	}

	// 16
	@Test
	public void foundTest() {
		String[] strs = { "Aaa", "Ccc", "Ddd", "Fff", "Hhh", "Ttt" };

		assertTrue(rf.found("Aaa", strs));
		assertTrue(rf.found("Hhh", strs));
		assertFalse(rf.found("Not here", strs));
	}

	// 17
	@Test
	public void binarySearchTest() {
		String[] strs = { "Aaa", "Ccc", "Ddd", "Fff", "Hhh", "Ttt" };

		assertEquals(0, rf.binarySearch("Aaa", strs));
		assertEquals(4, rf.binarySearch("Hhh", strs));
		assertEquals(-1, rf.binarySearch("Not here", strs));
	}

	// 18
	@Test
	public void testAddlastAndGet() {
		LinkedList<String> list = new LinkedList<String>();
		list.addLast("A");
		list.addLast("B");
		list.addLast("C");
		list.addLast("D");
		assertEquals("A", list.get(0));
		assertEquals("B", list.get(1));
		assertEquals("C", list.get(2));
		assertEquals("D", list.get(3));
	}

	// 19
	@Test
	public void maxTest() {
		LinkedList<Integer> list = new LinkedList<Integer>();
		list.addLast(6);
		list.addLast(1);
		list.addLast(8);
		list.addLast(5);
		assertEquals(list.get(2), "" + list.max());
	}
	@Test
	public void emptyMaxTest() {
		LinkedList<Integer> list = new LinkedList<Integer>();
		assertEquals("null", "" + list.max());
	}

	// 20
	@Test
	public void occurencesOfTest() {
		LinkedList<Integer> list = new LinkedList<Integer>();
		list.addLast(6);
		list.addLast(1);
		list.addLast(6);
		list.addLast(5);
		assertEquals(2, list.occurencesOf(6));
		assertEquals(1, list.occurencesOf(5));
		assertEquals(0, list.occurencesOf(4));
	}

	// 20
	@Test
	public void duplicateAllTest() {
		LinkedList<Integer> list = new LinkedList<Integer>();
		list.addLast(6);
		list.addLast(3);
		
		list.duplicateAll(6);
		assertEquals("6", "" + list.get(0));
		assertEquals("6", "" + list.get(1));
		//assertEquals("3", "" + list.get(2));
	}
}
