//Author Zachariah Rosson
public class LinkedList<E extends Comparable<E>> {

	private class Node {
		private E data;
		private Node next;

		public Node(E element) {
			data = element;
			next = null;
		}
	}

	private Node first;
	private int n;

	public LinkedList() {
		first = null;
		n = 0;
	}

	public int size() {
		return n;
	}

	// add to the list of nodes in the last position
	public void addLast(E el) {
		if (first == null)
			first = new Node(el);
		else
			addLast(el, first);
		n++;
	}

	// does the same thing as the one above but with dif inputs
	private void addLast(E el, Node ref) {
		if (ref.next == null)
			ref.next = new Node(el);
		else
			addLast(el, ref.next);
	}

	private int j = 0;

	// 18
	// in this method we will be getting the selected index
	@SuppressWarnings("unchecked")
	public E get(int index) {
		if (j < index) {
			j++;
			first = first.next;
			return get(index);
		} else
			return (E) ("" + first.data);
	}

	// 19___________________________________
	// in this method we will be finding the max of the nodes in the list
	public E max() {
		if (first == null)
			return null;

		E temp = first.data;
		return getMax(first, temp);
	}

	// helper method to find max
	public E getMax(Node ref, E currentMax) {

		if (ref == null) {
			return currentMax;
		}
		if (ref.data.compareTo(currentMax) > 0) {
			currentMax = ref.data;
			return getMax(ref.next, currentMax);
		} else
			return getMax(ref.next, currentMax);

	}

	// ----------------------------------------
	// 20________________________________________
	// in this method we will be finding how many times something occurs in the
	// list of nodes
	public int occurencesOf(E el) {
		if (el == null)
			return 0;

		return findO(0, el, first);
	}

	// helper to count how many times the word is in the list
	public int findO(int count, E check, Node ref) {
		if (ref == null) {
			return count;
		}
		if (ref.data.equals(check)) {
			count++;
			return findO(count, check, ref.next);
		} else
			return findO(count, check, ref.next);
	}

	// -----------------------------------------
	// 21_______________________________________
	// in this method we will be taking the array and duplicating the element
	// to the position next to it
	public void duplicateAll(E el) {
		if (isEmpty(first) == true)
			return;
		int x = getSize(first, 0);
		dAll(first, el, 0, x);
	}

	// helper method to copy copy copy and copy no paste maybe just a
	// little..... my head will explode if more methods are added
	public void dAll(Node ref, E elm, int counter, int x) {

		if (x == counter)
			return;

		if (ref.data == elm) {
			Node temp = ref;
			temp.next = ref.next;
			ref.next = temp;
			dAll(ref.next.next, elm, counter + 1, x);

		} else
			dAll(ref.next, elm, counter + 1, x);
	}

	// maybe this will help?
	private boolean isEmpty(Node ref) {
		if (ref == null)
			return true;
		else
			return false;
	}

	// to help?
	private int getSize(Node ref, int n) {
		if (ref == null)
			return n;
		else
			return getSize(ref.next, n + 1);
	}
}
