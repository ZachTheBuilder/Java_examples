
public interface PriorityList<T> {

}
