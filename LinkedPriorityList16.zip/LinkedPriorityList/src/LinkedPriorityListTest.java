
//Unit test for LinkedPriorityList<E> implements PriorityList<E>
/*
 * @author Zach Rosson
 * 
 * this class will go through and test every for see able problem in in the arrayPriortyList class
 */
import static org.junit.Assert.*;

import org.junit.Test;

public class LinkedPriorityListTest {

	@Test
	public void testInsertToLeftSpecialCaseWithZero() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		// Must shift array elements in this case
		((LinkedPriorityList<String>) list).insertElementAt(0, "New First");
		assertEquals("New First", ((LinkedPriorityList<String>) list).getElementAt(0));
		assertEquals("First", ((LinkedPriorityList<String>) list).getElementAt(1));
	}

	@Test
	public void testInsertToLeft() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "1");
		// Must shift array elements in this case
		((LinkedPriorityList<String>) list).insertElementAt(1, "2");
		((LinkedPriorityList<String>) list).insertElementAt(2, "3");
		assertEquals("1", ((LinkedPriorityList<String>) list).getElementAt(0));
		assertEquals("2", ((LinkedPriorityList<String>) list).getElementAt(1));
		assertEquals("3", ((LinkedPriorityList<String>) list).getElementAt(2));
	}

	// Write short test methods to ensure methods throw exceptions
	// when they are supposed to throw new IllegalArgumentException();
	@Test(expected = IllegalArgumentException.class)
	public void testExceptionGetElementAtZeroWhenSizeIsZero() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).getElementAt(0);
	}

	// check to see if size is working properly
	@Test
	public void testSize() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		assertEquals(0, ((LinkedPriorityList<String>) list).size());
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		// Must shift array elements in this case
		((LinkedPriorityList<String>) list).insertElementAt(0, "New First");
		assertEquals(2, ((LinkedPriorityList<String>) list).size());
	}

	// check to see if isEmpty is working properly
	@Test
	public void testIsEmpty() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		assertTrue(((LinkedPriorityList<String>) list).isEmpty());
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		// Must shift array elements in this case
		((LinkedPriorityList<String>) list).insertElementAt(0, "New First");
		assertFalse(((LinkedPriorityList<String>) list).isEmpty());
	}

	// this will test if get element is working when in bounds
	@Test
	public void testGetElementAt() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		// Must shift array elements in this case
		((LinkedPriorityList<String>) list).insertElementAt(0, "New First");
		assertEquals("New First", ((LinkedPriorityList<String>) list).getElementAt(0));
		assertEquals("First", ((LinkedPriorityList<String>) list).getElementAt(1));
	}

	// check to see if getElementat will throw an exception when the index is
	// larger than the useful amount
	@Test(expected = IllegalArgumentException.class)
	public void testExceptionGetElementAtZeroWhenSizeIsBiggerThenN() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		// Must shift array elements in this case
		((LinkedPriorityList<String>) list).insertElementAt(0, "New First");
		((LinkedPriorityList<String>) list).getElementAt(5);
	}

	// check to see if the insertElements is working properly
	@Test(expected = IllegalArgumentException.class)
	public void testInsertElementWhenFull() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "one");
		((LinkedPriorityList<String>) list).insertElementAt(1, "two");
		((LinkedPriorityList<String>) list).insertElementAt(2, "three");
		((LinkedPriorityList<String>) list).insertElementAt(3, "four");
		((LinkedPriorityList<String>) list).insertElementAt(4, "five");
		((LinkedPriorityList<String>) list).insertElementAt(5, "six");
		((LinkedPriorityList<String>) list).insertElementAt(6, "seven");
		((LinkedPriorityList<String>) list).insertElementAt(7, "eight");
		((LinkedPriorityList<String>) list).insertElementAt(8, "nine");
		((LinkedPriorityList<String>) list).insertElementAt(9, "ten");
		((LinkedPriorityList<String>) list).insertElementAt(10, "eleven");
		((LinkedPriorityList<String>) list).insertElementAt(11, "twelve");
		((LinkedPriorityList<String>) list).insertElementAt(12, "thirteen");
		((LinkedPriorityList<String>) list).insertElementAt(13, "fourteen");
		((LinkedPriorityList<String>) list).insertElementAt(14, "fifteen");
		((LinkedPriorityList<String>) list).insertElementAt(15, "sixteen");
		((LinkedPriorityList<String>) list).insertElementAt(16, "seventeen");
		((LinkedPriorityList<String>) list).insertElementAt(17, "eighteen");
		((LinkedPriorityList<String>) list).insertElementAt(18, "nineteen");
		((LinkedPriorityList<String>) list).insertElementAt(19, "twenty");
		// there should be no more room in the array the next one should throw
		// an IllegalArgumentException
		((LinkedPriorityList<String>) list).insertElementAt(26, "oh no, no room left at in array");
	}

	// check to see if removeElementAt is working properly
	@Test
	public void testRemoveElementAt() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "remove me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "dont remove me");
		assertEquals("remove me", ((LinkedPriorityList<String>) list).getElementAt(2));// should
																						// remove
																						// "remove
		// me"
		((LinkedPriorityList<String>) list).removeElementAt(2);
		assertEquals("dont remove me", ((LinkedPriorityList<String>) list).getElementAt(2));// should
																							// now
																							// show
		// "don't remove
		// me"
	}

	// check to see if IllegalArgumentException is thrown
	@Test(expected = IllegalArgumentException.class)
	public void testRemoveElementAtWhenNull() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First? no second");
		assertEquals("New First? no second", ((LinkedPriorityList<String>) list).getElementAt(2));
	}

	// checks to see if the method LowerPriorityOf is working properly
	@Test
	public void testLowerPriorityOf() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "and move me");
		assertEquals("move me", ((LinkedPriorityList<String>) list).getElementAt(2));
		((LinkedPriorityList<String>) list).lowerPriorityOf(2);
		assertEquals("and move me", ((LinkedPriorityList<String>) list).getElementAt(2));
	}

	// check to see if IllegalArgumentException is thrown
	@Test(expected = IllegalArgumentException.class)
	public void testLowerPriorityOfOutOfBounds() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "and move me");
		assertEquals("move me", ((LinkedPriorityList<String>) list).getElementAt(2));
		((LinkedPriorityList<String>) list).lowerPriorityOf(5);
	}

	// check to see if the method raisePriorityOf is working properly
	@Test
	public void testraisePriorityOf() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "and move me");
		assertEquals("and move me", ((LinkedPriorityList<String>) list).getElementAt(3));
		((LinkedPriorityList<String>) list).raisePriorityOf(3);
		assertEquals("move me", ((LinkedPriorityList<String>) list).getElementAt(3));
	}

	// check to see if IllegalArgumentException is thrown
	@Test(expected = IllegalArgumentException.class)
	public void testraisePriorityOfOutOfBounds() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "and move me");
		assertEquals("and move me", ((LinkedPriorityList<String>) list).getElementAt(3));
		((LinkedPriorityList<String>) list).raisePriorityOf(4);
		assertEquals("move me", ((LinkedPriorityList<String>) list).getElementAt(3));
	}

	// check to see if the method toArray is working properly
	@Test
	public void testToArray() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "and move me");
		((LinkedPriorityList<String>) list).toArray();

	}

	// check to see if IllegalArgumentException is thrown
	@Test
	public void testToArrayAtZero() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).toArray();
	}

	// check to see if method moveToLast is working properly
	@Test
	public void testMoveToLast() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "and move me");
		((LinkedPriorityList<String>) list).moveToLast(1);// move "New First" to
															// the last position
		assertEquals("First", ((LinkedPriorityList<String>) list).getElementAt(0));
		assertEquals("move me", ((LinkedPriorityList<String>) list).getElementAt(1));
		assertEquals("and move me", ((LinkedPriorityList<String>) list).getElementAt(2));
		assertEquals("New First", ((LinkedPriorityList<String>) list).getElementAt(3));
		((LinkedPriorityList<String>) list).moveToLast(3);// move "New First" to
															// the last position

	}

	// check to see if IllegalArgumentException is thrown
	@Test(expected = IllegalArgumentException.class)
	public void testMoveToLastOutOfBounds() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "and move me");
		((LinkedPriorityList<String>) list).moveToLast(5);
	}

	//
	// check to see if method moveToTop is working properly
	@Test
	public void testMoveToTop() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "not me");
		((LinkedPriorityList<String>) list).moveToTop(2);// move "move me" to
															// the first
															// position
		assertEquals("move me", ((LinkedPriorityList<String>) list).getElementAt(0));
		assertEquals("First", ((LinkedPriorityList<String>) list).getElementAt(1));
		assertEquals("New First", ((LinkedPriorityList<String>) list).getElementAt(2));
		assertEquals("not me", ((LinkedPriorityList<String>) list).getElementAt(3));
	}

	// check to see if IllegalArgumentException is thrown
	@Test(expected = IllegalArgumentException.class)
	public void testMoveToTopOutOfBounds() {
		PriorityList<String> list = new LinkedPriorityList<String>();
		((LinkedPriorityList<String>) list).insertElementAt(0, "First");
		((LinkedPriorityList<String>) list).insertElementAt(1, "New First");
		((LinkedPriorityList<String>) list).insertElementAt(2, "move me");
		((LinkedPriorityList<String>) list).insertElementAt(3, "and move me");
		((LinkedPriorityList<String>) list).moveToTop(-1);
	}
	// test growth method
	// @Test
	// public void testGrowth() {
	// PriorityList<String> list = new LinkedPriorityList<String>();
	// ((LinkedPriorityList<String>) list).insertElementAt(0, "one");
	// ((LinkedPriorityList<String>) list).insertElementAt(1, "two");
	// ((LinkedPriorityList<String>) list).insertElementAt(2, "three");
	// ((LinkedPriorityList<String>) list).insertElementAt(3, "four");
	// ((LinkedPriorityList<String>) list).insertElementAt(4, "five");
	// ((LinkedPriorityList<String>) list).insertElementAt(5, "six");
	// ((LinkedPriorityList<String>) list).insertElementAt(6, "seven");
	// ((LinkedPriorityList<String>) list).insertElementAt(7, "eight");
	// ((LinkedPriorityList<String>) list).insertElementAt(8, "nine");
	// ((LinkedPriorityList<String>) list).insertElementAt(9, "ten");
	// ((LinkedPriorityList<String>) list).insertElementAt(10, "eleven");
	// ((LinkedPriorityList<String>) list).insertElementAt(11, "twelve");
	// ((LinkedPriorityList<String>) list).insertElementAt(12, "thirteen");
	// ((LinkedPriorityList<String>) list).insertElementAt(13, "fourteen");
	// ((LinkedPriorityList<String>) list).insertElementAt(14, "fifteen");
	// ((LinkedPriorityList<String>) list).insertElementAt(15, "sixteen");
	// ((LinkedPriorityList<String>) list).insertElementAt(16, "seventeen");
	// ((LinkedPriorityList<String>) list).insertElementAt(17, "eighteen");
	// ((LinkedPriorityList<String>) list).insertElementAt(18, "nineteen");
	// ((LinkedPriorityList<String>) list).insertElementAt(19, "twenty");
	// ((LinkedPriorityList<String>) list).insertElementAt(20, "add more
	// room");// grow
	// assertEquals(21, ((LinkedPriorityList<String>) list).size());
	// }
} // End unit test for LinkedPriorityList
