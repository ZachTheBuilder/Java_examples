/*@author Zach Rosson
 * 
 * this class will implement node by adding more taking away moving them around
 * this class will also give the selected nodes a different priority in the list
 * by using the different methods below.
 */
public class LinkedPriorityList<E> implements PriorityList<E> {

	// This private inner class saves lots of typing and is hidden from
	// outsiders
	private class Node {

		// These instance variables can be accessed from the enclosing class
		private E data;
		private Node next;

		public Node(E element, Node link) {
			data = element;
			next = link;
		}
	}

	// These instance variables belong to the enclosing class
	private Node first;
	private int size;

	// Create an empty list with zero elements
	public LinkedPriorityList() {
		first = null;
		size = 0;
	}

	// this will return the size of the linked list
	public int size() {
		return size;
	}

	// this will check to see if the linked list is empty or not by checking the
	// size
	public boolean isEmpty() {
		if (size == 0)
			return true;
		return false;
	}

	// this will insert the given element at the given position within the
	// linked list
	public void insertElementAt(int index, E el) throws IllegalArgumentException {
		size++; // Increases size to pass check
		if (index < 0 || index > size - 1) {
			size--; // decreases size if index does not meet requirements
			throw new IllegalArgumentException();
		} else {
			if (index == 0) {
				first = new Node(el, first);
				// creates new node if index is 0
			} else {

				Node ref = first; // reference node

				// ref goes through array until it hits index
				for (int i = 1; i < index; i++) {
					ref = ref.next;
					// adds .next to go through the linked list
				}
				if (index == size - 1)
					ref.next = new Node(el, null);
				// Creates new node and current node points to it
				// while new node points to old nodes .next
				else
					ref.next = new Node(el, ref.next);
			}
		}
	}

	// this will go through the linked list to get the element at the give
	// position
	public E getElementAt(int index) throws IllegalArgumentException {
		if (index < 0 || index > size - 1) {
			throw new IllegalArgumentException();
		} else {
			Node ref = first;

			// If index is zero, return current data
			if (index == 0) {
				return ref.data;
			} else {
				for (int i = 1; i < index; i++) {
					ref = ref.next;
				}
				return ref.next.data;
			}
		}
	}

	// this will go through the linked list to remove the element at the give
	// position
	public void removeElementAt(int index) throws IllegalArgumentException {
		if (index < 0 || index > size) {
			throw new IllegalArgumentException();
		} else {
			int temp = 0;
			Node ref = first;
			// As long as the list isn't null remove element
			if (first != null) {
				if (index == 0 && size == 1) {
					ref.next = null; // remove reference to first node
					size--;
				} else if (index == 0 && size > 1) {
					first = first.next; // removes first element
					size--;
				} else {
					while (ref.next.next != null && temp != index - 1) {
						ref = ref.next;
						temp++;
					}
					ref.next = ref.next.next;
					size--; // decrease size
				}
			}
		}
	}

	// this will go through the linked list to lower priority of the element at
	// the give position
	public void lowerPriorityOf(int index) throws IllegalArgumentException {
		Node ref = first;
		int tempCounter = 0;
		if (index < 0 || index > size - 1) {
			throw new IllegalArgumentException();
		} else {
			for (int i = 0; i < index; i++) {
				ref = ref.next;
				tempCounter++;
			}
			// Not the first element lowers eleement
			if (tempCounter != size - 1) {
				insertElementAt(tempCounter + 2, ref.data);
				removeElementAt(index);
			}
		}
	}

	// this will go through the linked list to raise priority of the element at
	// the give position
	public void raisePriorityOf(int index) throws IllegalArgumentException {
		Node ref = first;
		int tempCounter = 0;
		if (index < 0 || index > size - 1) {
			throw new IllegalArgumentException();
		} else {
			for (int i = 0; i < index; i++) {
				ref = ref.next;
				tempCounter++;
			}

			// Raises priority of everything except the top of the list
			if (tempCounter != 0) {
				insertElementAt(tempCounter - 1, ref.data);
				removeElementAt(index + 1);
			}
		}
	}

	// this will take each element in the linked list and add it to an array of
	// objects
	public Object[] toArray() {
		int tempCount = 0;
		Node ref = first;
		Object[] arrayOfData = new Object[size];
		if (size == 0) {
			return arrayOfData;
		}
		if (size == 1) {
			arrayOfData[0] = ref.data;
		} else {

			// Puts all elements from linked list into array
			while (tempCount != size) {
				arrayOfData[tempCount] = ref.data;
				ref = ref.next;
				tempCount++;
			}
		}
		return arrayOfData;
	}

	// this will go through the linked list to move the element at
	// the give position to the last position
	public void moveToLast(int index) throws IllegalArgumentException {
		Node ref = first;
		// Node temp = first;
		if (index < 0 || index > size - 1) {
			throw new IllegalArgumentException();
		} else {
			for (int i = 0; i < index; i++) {
				ref = ref.next;
			}
			// Inserts Node at tend and removes current node
			insertElementAt(size, ref.data);
			removeElementAt(index);
		}
	}

	// this will go through the linked list to move the element at
	// the give position to the top
	public void moveToTop(int index) throws IllegalArgumentException {
		Node ref = first;
		// Node temp = first;
		if (index < 0 || index > size - 1) {
			throw new IllegalArgumentException();
		} else {
			for (int i = 0; i < index; i++) {
				ref = ref.next;
			}
			// Inserts Node at beginning of linked list
			insertElementAt(0, ref.data);
			removeElementAt(index + 1);
		}
	}
}