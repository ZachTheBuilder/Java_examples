import java.util.Random;
import java.util.Stack;

/**
 * This class represents the model for a game of MineSweeper. It has a
 * constructor that takes a preset boolean 2D array where true means there is a
 * mine. This first constructor (you'll need 2) is for testing the methods of
 * this class.
 * 
 * The second constructor that takes the number of rows, the number of columns,
 * and the number of mines to be set randomly in that sized mine field. Do this
 * last.
 * 
 * @author Zachariah Rosson
 */
// THIS CLASS will take given information from the click method and change it
// According to the rules set in place to make this game run
public class MineSweeper implements MineSweeperModel {

	private class GameSquare {

		private boolean isMine;
		private int row;
		private int col;
		private boolean isVisible;
		private boolean isFlagged;
		private int mineNeighbors;

		// Construct a GameSquare object with all values initialized except
		// mineNeighbors, which is an instance variables that can only be set
		// after
		// all
		// GameSquare objects have been constructed in the 2D array.
		public GameSquare(boolean isMine, int row, int col) {
			this.isMine = isMine;
			this.row = row;
			this.col = col;
			isVisible = false; // Default until someone starts clicking
			isFlagged = false; // Default until someone starts clicking
			// call setAdjacentMines() from both constructors
			// to set this for each new GameSquare.
			mineNeighbors = 0;
		}
	}

	// The instance variable represents all GameSquare objects where each knows
	// its row,
	// column, number of mines around it, if it is a mine, flagged, or visible
	private GameSquare[][] board;

	/**
	 * Construct a MineSweeper object using a given mine field represented by an
	 * array of boolean values: true means there is mine, false means there is
	 * not a mine at that location.
	 * 
	 * @param mines
	 *            A 2D array to represent a mine field so all methods can be
	 *            tested with no random placements.
	 */
	public MineSweeper(boolean[][] mines) {
		// TODO: Complete this constructor first so you can test preset mine
		// fields
		// (later on you will need to write another constructor for random
		// boards).
		// new GameSquare objects store all info about one square on the board
		// such
		// as its row, column, if it's flagged, visible, or is a mine.

		board = new GameSquare[mines.length][mines[0].length];
		// set each position in board == to GameSquare
		for (int x = 0; x < mines.length; x++) {
			for (int y = 0; y < mines[0].length; y++) {
				board[x][y] = new GameSquare(mines[x][y], x, y);
			}
		}
		// Example construction of one GameSquare stored in row 2, column 4:
		// /// board[2][4] = new GameSquare(mines[2][4], 2, 4);
		// Use a nested for loop to change all board array elements
		// from null to a new GameSquare

		// You will need to call private void setAdjacentMines() to set
		// mineNeighbors for all GameSquare objects because each GameSquare
		// object
		// must first know if it is a mine or not. Set mineNeighbors for each.
		setAdjacentMines();
	}

	/**
	 * Use the almost initialized 2D array of GameSquare objects to set the
	 * instance variable mineNeighbors for every 2D array element (even if that
	 * one GameSquare has a mine). This is similar to GameOfLife neighborCount.
	 */

	private void setAdjacentMines() {
		// Example to set the instance variable mineNeighbors of the one
		// GameSquare
		// object stored in row 2, column 4 to 8:
		///// board[2][4].mineNeighbors = 8;
		// Use a nested for loop to set mineNeighbors for ALL GameSquare objects
		for (int x = 0; x < board.length; x++) {
			for (int y = 0; y < board[0].length; y++) {
				if (x == 0 && y == 0) {// BLC
					// checks adj squares to the bottom left corner of the bo
					if (board[0][1].isMine)
						board[x][y].mineNeighbors++;
					if (board[1][1].isMine)
						board[x][y].mineNeighbors++;
					if (board[1][0].isMine)
						board[x][y].mineNeighbors++;

				} else if (x == 0 && y == board[0].length - 1) {// BRC
					// checks adj squares to the bottom right corner of the bo
					if (board[0][board[0].length - 2].isMine)
						board[x][y].mineNeighbors++;
					if (board[1][board[0].length - 2].isMine)
						board[x][y].mineNeighbors++;
					if (board[1][board[0].length - 1].isMine)
						board[x][y].mineNeighbors++;

				} else if (x == board.length - 1 && y == board[0].length - 1) {// TRC
					// checks adj squares to the top right corner of the bo
					if (board[board.length - 2][board[0].length - 1].isMine)
						board[x][y].mineNeighbors++;
					if (board[board.length - 2][board[0].length - 2].isMine)
						board[x][y].mineNeighbors++;
					if (board[board.length - 1][board[0].length - 2].isMine)
						board[x][y].mineNeighbors++;

				} else if (x == board.length - 1 && y == 0) {// TLC
					// checks adj squares to the top left corner of the bo
					if (board[board.length - 2][0].isMine)
						board[x][y].mineNeighbors++;
					if (board[board.length - 2][1].isMine)
						board[x][y].mineNeighbors++;
					if (board[board.length - 1][1].isMine)
						board[x][y].mineNeighbors++;

				} else if (x == 0 && y > 0 && y < board[0].length - 1) {// BE
					// checks adj squares to the bottom of the bo
					if (board[x][y - 1].isMine)// left
						board[x][y].mineNeighbors++;
					if (board[x][y + 1].isMine)// right
						board[x][y].mineNeighbors++;
					if (board[x + 1][y].isMine)// up
						board[x][y].mineNeighbors++;
					if (board[x + 1][y - 1].isMine)// Dag up left
						board[x][y].mineNeighbors++;
					if (board[x + 1][y + 1].isMine)// Dag up right
						board[x][y].mineNeighbors++;

				} else if (x == board.length - 1 && y > 0 && y < board[0].length - 1) {// TE
					// checks adj squares to the top of the bo
					if (board[x][y - 1].isMine)// left
						board[x][y].mineNeighbors++;
					if (board[x][y + 1].isMine)// right
						board[x][y].mineNeighbors++;
					if (board[x - 1][y].isMine)// down
						board[x][y].mineNeighbors++;
					if (board[x - 1][y - 1].isMine)// Dag down left
						board[x][y].mineNeighbors++;
					if (board[x - 1][y + 1].isMine)// Dag down right
						board[x][y].mineNeighbors++;

				} else if (x > 0 && x < board.length - 1 && y == 0) {// LE
					// checks adj squares to the left side of the bo
					if (board[x + 1][y].isMine)// up
						board[x][y].mineNeighbors++;
					if (board[x - 1][y].isMine)// down
						board[x][y].mineNeighbors++;
					if (board[x][y + 1].isMine)// right
						board[x][y].mineNeighbors++;
					if (board[x + 1][y + 1].isMine)// Dag down up
						board[x][y].mineNeighbors++;
					if (board[x - 1][y + 1].isMine)// Dag down down
						board[x][y].mineNeighbors++;

				} else if (x > 0 && x < board.length - 1 && y == board[0].length - 1) {// RE
					// checks adj squares to the right side of the board
					if (board[x + 1][y].isMine)// up
						board[x][y].mineNeighbors++;
					if (board[x - 1][y].isMine)// down
						board[x][y].mineNeighbors++;
					if (board[x][y - 1].isMine)// left
						board[x][y].mineNeighbors++;
					if (board[x + 1][y - 1].isMine)// Dag down up
						board[x][y].mineNeighbors++;
					if (board[x - 1][y - 1].isMine)// Dag down down
						board[x][y].mineNeighbors++;

				} else {
					// everything in the middle of the board
					if (board[x + 1][y].isMine)// up
						board[x][y].mineNeighbors++;
					if (board[x - 1][y].isMine)// down
						board[x][y].mineNeighbors++;
					if (board[x][y - 1].isMine)// left
						board[x][y].mineNeighbors++;
					if (board[x][y + 1].isMine)// right
						board[x][y].mineNeighbors++;
					if (board[x + 1][y - 1].isMine)// Dag left up
						board[x][y].mineNeighbors++;
					if (board[x - 1][y - 1].isMine)// Dag left down
						board[x][y].mineNeighbors++;
					if (board[x + 1][y + 1].isMine)// Dag right up
						board[x][y].mineNeighbors++;
					if (board[x - 1][y + 1].isMine)// Dag right down
						board[x][y].mineNeighbors++;
				}
			}
		}
	}

	// this method will go through and check the corners and sides specially and
	// then it will check the middle normally for any adj mines
	public int getAdjacentMines(int row, int column) {
		// with the given position it will go through the nested for loop
		// checking to see if there are any adjacent mines
		return board[row][column].mineNeighbors;
	}

	public MineSweeper(int rows, int columns, int numberOfMines) {
		// Consider using class Random with its nextInt(int) method
		//
		// Random generator = new Random();
		// int r = generator(rows);
		// assertTrue(r >= 0 && r < rows);

		board = new GameSquare[rows][columns];

		// Looks through squares and initializes them
		for (int x = 0; x < rows; x++) {
			for (int y = 0; y < columns; y++) {
				board[x][y] = new GameSquare(false, x, y);
			}
		}
		for (int i = 0; i < numberOfMines; i++) {
			Random generator = new Random();
			int x = generator.nextInt(rows);
			int y = generator.nextInt(columns);
			board[x][y].isMine = true;
		}
	}

	// this method will check to see how many mines there are
	public int getTotalMineCount() {
		// go through the board and find how many mines there are
		int mineCounter = 0;

		for (int x = 0; x < board.length; x++) {
			for (int y = 0; y < board[1].length; y++) {
				if (board[x][y].isMine == true)
					mineCounter++;
			}
		}

		return mineCounter;
	}

	public boolean isFlagged(int row, int column) {
		// this checks if the position is flagged
		return board[row][column].isFlagged;
	}

	public void toggleFlagged(int row, int column) {
		// this will toggle back and forth the flag in the given position
		if (board[row][column].isFlagged == true)
			board[row][column].isFlagged = false;
		else if (board[row][column].isFlagged == false)
			board[row][column].isFlagged = true;
	}

	// this method will check to see if the position is a mine
	public boolean isMine(int row, int column) {
		// if position in array is mine than true else false
		return board[row][column].isMine;
	}

	public boolean isVisible(int row, int column) {
		// this will check if visible or not
		return board[row][column].isVisible;
	}

	public boolean lost() {
		// check if a boom a boom has been chosen
		for (int x = 0; x < board.length; x++) {
			for (int y = 0; y < board.length; y++) {
				if (board[x][y].isVisible && board[x][y].isMine)
					return true;
			}
		}
		return false;
	}

	public String toString() {
		// this shows the given board
		/////// not done////////
		String printOut = "";
		for (int x = 0; x < board.length; x++) {
			for (int y = 0; y < board[0].length; y++) {
				if (board[x][y].isMine)
					printOut += "T ";
				else if (!board[x][y].isMine)
					printOut += "F ";
				else if (board[x][y].isFlagged)
					printOut += " > ";
			}
		}

		return printOut;
	}

	public boolean won() {
		// check if lost if not if board if still in play
		if (lost() == true)
			return false;
		for (int x = 0; x < board.length; x++) {
			for (int y = 0; y < board.length; y++) {
				if (board[x][y].isVisible && !board[x][y].isMine)
					return false;
			}
		}
		return true;
	}

	public void click(int row, int column) {
		// check if flagged or visible if yes move on
		if (board[row][column].isFlagged || board[row][column].isVisible)
			return;
		// if mine chosen lose
		else if (board[row][column].isMine) {
			board[row][column].isVisible = true;
			lost();
		} else if (getAdjacentMines(row, column) > 0) {
			board[row][column].isVisible = true;
		} else {
			// turn into a stack
			Stack<GameSquare> stack = new Stack<GameSquare>();

			stack.push(board[row][column]);
			board[row][column].isVisible = true;
			while (!stack.isEmpty()) {
				GameSquare temp = stack.pop();
				if (getAdjacentMines(temp.row, temp.col) == 0) {
					for (int x = -1; x < 2; x++) {
						for (int y = -1; y < 2; y++) {
							if (temp.row + x < 0 || temp.col + y < 0 || temp.row + x > board.length - 1
									|| temp.col + y > board.length - 1) {
								continue;
							}
							if (!board[temp.row + x][temp.col + y].isVisible
									&& !board[temp.row + x][temp.col + y].isFlagged) {
								if (!board[temp.row + x][temp.col + y].isMine) {
									stack.push(board[temp.row + x][temp.col + y]);
									board[temp.row + x][temp.col + y].isVisible = true;
								} 
							}
						}
					}
				}
			}
		}
	}
}
