import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * A model for the game of 20 questions
 * 
 * @author Zachariah Rosson
 */
public class GameTree {

	/**
	 * Constructor needed to create the game.
	 * 
	 * @param name
	 *            this is the name of the file we need to import the game
	 *            questions and answers from.
	 */
	private String currentFileName;
	private GameTree root;
	private GameTree left;
	private GameTree right;
	private GameTree current;
	private String data;
	private Scanner inFile;

	public GameTree(String name) {
		// TODO: Complete this method
		currentFileName = name;
		try {
			inFile = new Scanner(new File(currentFileName));
		} catch (FileNotFoundException E) {
		}

		root = build();
		current = root;
		inFile.close();
	}

	private GameTree(String token, GameTree leftTree, GameTree rightTree) {
		data = token;
		left = leftTree;
		right = rightTree;
	}

	// build the tree
	private GameTree build() {
		if (!inFile.hasNextLine())
			return null;

		String token = inFile.nextLine();
		if (isQuestion(token)) {
			GameTree temp = new GameTree(token, null, null);
			temp.left = build();
			temp.right = build();
			return temp;
		} else {
			return new GameTree(token, null, null);
		}

	}

	// check if the node is a question or not
	private boolean isQuestion(String token) {
		if (token.indexOf("?") >= 0)
			return true;
		else
			return false;

	}

	/*
	 * Add a new question and answer to the currentNode. If the current node has
	 * the answer chicken, theGame.add("Does it swim?", "goose"); should change
	 * that node like this:
	 */
	// -----------Feathers?-----------------Feathers?------
	// -------------/----\------------------/-------\------
	// ------- chicken horse-----Does it swim?-----horse--
	// -----------------------------/------\---------------
	// --------------------------goose--chicken-----------
	/**
	 * @param newQuestion
	 *            The question to add where the old answer was.
	 * @param newAnswer
	 *            The new Yes answer for the new question.
	 */
	// this will add to the existing tree node
	public void add(String newQuestion, String newAnswer) {
		// TODO: Complete this method
		String temp = current.data;
		current.data = newQuestion;
		current.left = new GameTree(newAnswer, null, null);
		current.right = new GameTree(temp, null, null);
	}

	/**
	 * True if getCurrent() returns an answer rather than a question.
	 * 
	 * @return False if the current node is an internal node rather than an
	 *         answer at a leaf.
	 */
	// this will check weather or not if the node is a question or an answer
	public boolean foundAnswer() {
		// TODO: Complete this method
		if (!isQuestion(getCurrent())) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Return the data for the current node, which could be a question or an
	 * answer.
	 * 
	 * @return The current question or answer.
	 */
	// this will return the current positions data
	public String getCurrent() {
		// TODO: Complete this method
		return current.data;
	}

	/**
	 * Ask the game to update the current node by going left for Choice.yes or
	 * right for Choice.no Example code: theGame.playerSelected(Choice.Yes);
	 * 
	 * @param yesOrNo
	 */
	// this will deicide weather or not you go left or right in the tree
	public void playerSelected(Choice yesOrNo) {
		// TODO: Complete this method
		if (yesOrNo == Choice.Yes)
			current = current.left;
		else
			current = current.right;
	}

	/**
	 * Begin a game at the root of the tree. getCurrent should return the
	 * question at the root of this GameTree.
	 */
	// this will send the player back to the start
	public void reStart() {
		// TODO: Complete this method
		current = root;
	}

	/**
	 * Return a textual version of this object
	 */
	@Override
	public String toString() {
		// TODO: Complete this method
		return toStringHelper();
	}

	private String toStringHelper() {
		return "Help me";

	}

	/**
	 * Overwrite the old file for this gameTree with the current state that may
	 * have new questions added since the game started.
	 * 
	 */

	// this will save the game at the current spot also will save all added
	// questions
	public void saveGame() {
		// TODO: Complete this method
		FileWriter write = null;

		try {
			write = new FileWriter(currentFileName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
		PrintWriter dFile = new PrintWriter(write);
		saveGameHelp(root, dFile);
		dFile.close();
	}

	// helps the saveGame method
	public void saveGameHelp(GameTree t, PrintWriter dFile) {
		if (t != null) {
			dFile.println(t.data);
			saveGameHelp(t.left, dFile);
			saveGameHelp(t.right, dFile);
		}
	}
}