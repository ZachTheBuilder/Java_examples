import static org.junit.Assert.*;

import org.junit.Test;

// Author: Zach rosson

public class OrderedSetTests {
	
	@Test
	public void testInsertSizeAndTostringinorder() {
		OrderedSet<String> bst = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertTrue(bst.insert("d"));
		assertTrue(bst.insert("b"));
		assertTrue(bst.insert("e"));
		assertFalse(bst.insert("e"));
		assertTrue(bst.insert("a"));
		assertEquals(4, bst.size());
		assertEquals("a b d e", bst.toStringInorder());
	}
	
	@Test 
	public void testSubSet() {
		OrderedSet<Integer> bst = new OrderedSet<Integer>();
		assertEquals("", bst.subset(12, 12).toStringInorder());
		bst.insert(50);
		bst.insert(25);
		bst.insert(12);
		bst.insert(75);
		bst.insert(65);
		bst.insert(90);
		assertEquals("12 25 50 65 75 90", bst.toStringInorder());
		assertEquals("12 25", bst.subset(1, 49).toStringInorder());
		assertEquals("25 50 65", bst.subset(25, 75).toStringInorder());
		assertEquals("", bst.subset(12, 12).toStringInorder()); // 12 < 12 is false
		}
	
	@Test
	public void containsTest() {
		OrderedSet<String> bst = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertFalse(bst.contains("a"));
		assertTrue(bst.insert("d"));
		assertTrue(bst.insert("b"));
		assertTrue(bst.insert("e"));
		assertFalse(bst.insert("e"));
		assertTrue(bst.insert("a"));
		assertEquals("a b d e", bst.toStringInorder());
		assertTrue(bst.contains("b"));
		assertFalse(bst.contains("c"));
	}
	
	@Test
	public void maxTest() {
		OrderedSet<String> bst = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertEquals(null, bst.max());
		assertTrue(bst.insert("d"));
		assertEquals("d", bst.max());
		assertTrue(bst.insert("b"));
		assertTrue(bst.insert("e"));
		assertFalse(bst.insert("e"));
		assertTrue(bst.insert("a"));
		assertEquals("e", bst.max());
		assertEquals("a b d e", bst.toStringInorder());
	}
	
	@Test
	public void nodesAtLevelTest() {
		OrderedSet<String> bst = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertEquals(0, bst.nodesAtLevel(0));
		assertTrue(bst.insert("d"));
		assertTrue(bst.insert("b"));
		assertTrue(bst.insert("e"));
		assertFalse(bst.insert("e"));
		assertTrue(bst.insert("a"));
		assertEquals("a b d e", bst.toStringInorder());
		assertEquals(1, bst.nodesAtLevel(0));
		assertEquals(2, bst.nodesAtLevel(1));
		assertEquals(1, bst.nodesAtLevel(2));
		assertEquals(0, bst.nodesAtLevel(3));
	}
	
	@Test
	public void sameStructureTest() {
		OrderedSet<String> bst = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertTrue(bst.insert("d"));
		assertTrue(bst.insert("b"));
		assertTrue(bst.insert("e"));
		assertFalse(bst.insert("e"));
		assertTrue(bst.insert("a"));
		assertEquals("a b d e", bst.toStringInorder());
		assertEquals(1, bst.nodesAtLevel(0));
		assertEquals(2, bst.nodesAtLevel(1));
		assertEquals(1, bst.nodesAtLevel(2));
		assertEquals(0, bst.nodesAtLevel(3));
	}
	
	@Test
	public void removeTest() {
		OrderedSet<String> bst = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertFalse(bst.remove("c"));
		assertTrue(bst.insert("d"));
		assertTrue(bst.insert("b"));
		assertTrue(bst.insert("e"));
		assertFalse(bst.insert("e"));
		assertTrue(bst.insert("a"));
		assertEquals("a b d e", bst.toStringInorder());
		assertTrue(bst.contains("a"));
		assertTrue(bst.remove("a"));
		assertFalse(bst.remove("c"));
		bst.remove("b");
		assertEquals("d e", bst.toStringInorder());
		assertTrue(bst.remove("e"));
	}
	
	@Test
	public void intersectionTest() {
		OrderedSet<String> bst = new OrderedSet<String>();
		OrderedSet<String> bst2 = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertTrue(bst.insert("d"));
		assertTrue(bst.insert("b"));
		assertTrue(bst.insert("e"));
		assertFalse(bst.insert("e"));
		assertTrue(bst.insert("a"));
		assertEquals("a b d e", bst.toStringInorder());
		assertEquals("", bst.intersection(bst2).toStringInorder());
		assertTrue(bst2.insert("a"));
		assertTrue(bst2.insert("b"));
		assertEquals("a b", bst.intersection(bst2).toStringInorder());
	}
	
	@Test
	public void intersectionWhenNUllTest(){
		OrderedSet<String> bst = new OrderedSet<String>();
		OrderedSet<String> bst2 = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertEquals("", bst.intersection(bst2).toStringInorder());
	}
	
	@Test
	public void unionWhenNUllTest(){
		OrderedSet<String> bst = new OrderedSet<String>();
		OrderedSet<String> bst2 = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertTrue(bst2.insert("a"));
		assertTrue(bst2.insert("b"));
		assertEquals("a b", bst2.toStringInorder());
		assertEquals("a b", bst.union(bst2).toStringInorder());
	}
	
	@Test
	public void unionTest(){
		OrderedSet<String> bst = new OrderedSet<String>();
		OrderedSet<String> bst2 = new OrderedSet<String>();
		assertEquals("", bst.toStringInorder());
		assertTrue(bst.insert("a"));
		assertTrue(bst.insert("b"));
		assertTrue(bst2.insert("c"));
		assertTrue(bst2.insert("d"));
		assertEquals("a b c d", bst.union(bst2).toStringInorder());
	}

	@Test
	public void subSameStructureTest(){
		OrderedSet<String> bst = new OrderedSet<String>();
		OrderedSet<String> bst2 = new OrderedSet<String>();
		assertFalse(bst.sameStructure(bst2));
		assertTrue(bst.insert("a"));
		assertTrue(bst.insert("b"));
		assertTrue(bst2.insert("c"));
		assertTrue(bst2.insert("d"));
		assertFalse(bst.sameStructure(bst2));
	}
	
	@Test
	public void subSameStructureWhennullTest(){
		OrderedSet<String> bst = new OrderedSet<String>();
		OrderedSet<String> bst2 = new OrderedSet<String>();
		assertFalse(bst.sameStructure(bst2));
	}
}
