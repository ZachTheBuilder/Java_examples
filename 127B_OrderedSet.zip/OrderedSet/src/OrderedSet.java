//Author: Zach Rosson
//this class will store a collection of nodes in a binary search tree
//by several of the methods below we will keep track of size and where
//the nodes will be put in the binary search treee

public class OrderedSet<E extends Comparable<E>> {

	private class TreeNode {
		private E data;
		private TreeNode left;
		private TreeNode right;

		public TreeNode(E tempData) {
			data = tempData;
			left = null;
			right = null;
		}
	}

	private TreeNode root;

	public boolean insert(E element) {
		// element will be added and this will still be a BinarySearchTree.
		// This tree will not insert newElement if it will compareTo an existing
		// element equally.
		if (root == null) {
			root = new TreeNode(element);
			return true;
		} else {
			// find the proper leaf to attach to
			TreeNode curr = root;
			TreeNode prev = root;
			while (curr != null) {
				prev = curr;
				if (element.compareTo(curr.data) < 0)
					curr = curr.left;
				else if (element.compareTo(curr.data) > 0)
					curr = curr.right;
				else {
					return false;
				}
			}
			// Determine whether to link the new node came from prev.left or
			// prev.right
			if (element.compareTo(prev.data) < 0) {
				prev.left = new TreeNode(element);
				return true;
			} else {
				prev.right = new TreeNode(element);
				return true;
			}
		}
	}

	// this will check the size of the ordered set
	public int size() {
		return size(root);
	}

	private int size(TreeNode t) {
		if (t == null)
			return 0;
		else
			return 1 + size(t.left) + size(t.right);
	}

	String str = "";

	// this will take the ordered set and hange it into a string
	private String toStringInorderHelper(TreeNode curr) {
		if (curr != null) {
			toStringInorderHelper(curr.left);
			str += curr.data + " ";
			toStringInorderHelper(curr.right);
		}
		return str.trim();
	}

	public String toStringInorder() {
		if (root == null)
			return "";
		else {
			TreeNode curr = root;
			str = "";
			return toStringInorderHelper(curr);
		}
	}

	// this will check the ordred set to see if it is there
	private boolean containsHelper(TreeNode curr, E search) {
		while (curr != null) {
			if (search.equals(curr.data))
				return true;
			else if ((search.compareTo(curr.data) < 0))
				curr = curr.left;
			else
				curr = curr.right;
		}
		return false;
	}

	public boolean contains(E search) {
		if (root == null)
			return false;
		else {
			TreeNode curr = root;
			return containsHelper(curr, search);
		}
	}

	// this will find the max of the ordred set
	public E max() {
		if (root != null) {
			TreeNode curr = root;
			return maxHelper(curr);
		}
		return null;
	}

	private E maxHelper(TreeNode curr) {
		if (curr.right == null)
			return curr.data;
		else {
			return maxHelper(curr.right);
		}
	}

	// this will check to see how many nodes are at the given lvl
	public int nodesAtLevel(int level) {
		if (root == null)
			return 0;
		else {
			TreeNode curr = root;
			return levelCount(curr, level);
		}
	}

	private int levelCount(TreeNode curr, int level) {
		if (curr == null)
			return 0;
		else if (level == 0)
			return 1;
		return levelCount(curr.left, level - 1) + levelCount(curr.right, level - 1);
	}

	private OrderedSet<E> intersectionHelper(OrderedSet<E> other, TreeNode curr, OrderedSet<E> newThing) {
		if (curr != null) {
			if (curr.left != null)
				intersectionHelper(other, curr.left, newThing);
		}

		if (curr.data != null)
			if (other.contains(curr.data)) {
				newThing.insert(curr.data);
			}

		if (curr.right != null)
			intersectionHelper(other, curr.right, newThing);
		return newThing;
	}

	//
	public OrderedSet<E> intersection(OrderedSet<E> other) {
		OrderedSet<E> newThing = new OrderedSet<E>();
		TreeNode curr = root;
		if (root == null)
			return newThing;
		else {
			return intersectionHelper(other, curr, newThing);
		}
	}

	private OrderedSet<E> unionHelper(OrderedSet<E> other, TreeNode curr) {
		if (curr.left != null)
			unionHelper(other, curr.left);
		if (curr.data != null)
			other.insert(curr.data);
		if (curr.right != null)
			unionHelper(other, curr.right);
		return other;
	}

	// this will combine the two ordered sets
	public OrderedSet<E> union(OrderedSet<E> other) {
		TreeNode curr = root;
		if (root != null)
			return unionHelper(other, curr);
		return other;
	}

	private OrderedSet<E> subsetHelper(E inclusive, E exclusive, TreeNode curr, OrderedSet<E> newSubset) {
		if (curr != null) {
			if (curr.left != null)
				subsetHelper(inclusive, exclusive, curr.left, newSubset);
			if (curr.data != null && ((Comparable<E>) curr.data).compareTo(inclusive) >= 0
					&& ((Comparable<E>) curr.data).compareTo(exclusive) < 0)
				newSubset.insert(curr.data);
			if (curr.right != null)
				subsetHelper(inclusive, exclusive, curr.right, newSubset);
		}
		return newSubset;
	}

	public OrderedSet<E> subset(E inclusive, E exclusive) {
		OrderedSet<E> newSubset = new OrderedSet<E>();
		TreeNode curr = root;
		if (root != null)
			return subsetHelper(inclusive, exclusive, curr, newSubset);
		return newSubset;
	}

	// this will get the height of the node
	public int height() {
		return heightHelper(root);
	}

	private int heightHelper(TreeNode curr) {
		if (curr == null)
			return -1;
		else
			return 1 + Math.max(heightHelper(curr.left), heightHelper(curr.right));
	}

	// this is to help SS with leafs
	public int leafs() {
		return leafs(root);
	}

	private int leafs(TreeNode t) {
		if (t == null)
			return 0;
		else {
			int result = 0;
			if (t.left == null && t.right == null)
				result = 1;
			return result + leafs(t.left) + leafs(t.right);
		}
	}

	// this is to help SS
	private boolean sameLevels(OrderedSet<E> other) {
		boolean compareTheSame = false;
		for (int i = 0; i < height(); i++) {
			if (other.nodesAtLevel(i) == nodesAtLevel(i))
				compareTheSame = true;
			compareTheSame = false;
		}
		return compareTheSame;
	}

	public boolean compareChldrenCount(OrderedSet<E> other) {
		return compareChldrenCountHelper(other, root);
	}

	// this is to help SS by comparing
	private boolean compareChldrenCountHelper(OrderedSet<E> other, TreeNode curr) {
		if (curr == null)
			return true;
		if ((checkLeaf(curr) && !other.checkLeaf(curr)) || (!checkLeaf(curr) && other.checkLeaf(curr))) {
			return false;
		} else
			return compareChldrenCountHelper(other, curr.left) && compareChldrenCountHelper(other, curr.right);
	}

	// this is to get the leaf for SS
	private boolean checkLeaf(TreeNode curr) {
		if (curr == root)
			return true;
		return curr.left == null && curr.right == null;
	}

	private boolean sameStructureHelper(OrderedSet<E> other, TreeNode curr) {
		if (curr != null) {
			if (curr.data != null && other.height() == height() && other.leafs() == leafs() && other.size() == size()
					&& sameLevels(other) == true && size() - leafs() == other.size() - other.leafs()
					&& compareChldrenCount(other))
				return true;
		}
		return false;
	}
//check if two ordered sets have the same or different structures
	public boolean sameStructure(OrderedSet<E> other) {
		OrderedSet<E> newSubset = new OrderedSet<E>();
		TreeNode curr = root;
		if (curr == null && other == null)
			return true;
		if (root != null)
			return sameStructureHelper(newSubset, curr);
		return false;
	}

	private boolean removeHelper(E element, TreeNode curr, TreeNode prev) {
		while (!curr.data.equals(element)) {
			prev = curr;
			if (element.compareTo(curr.data) < 0)
				curr = curr.left;
			else
				curr = curr.right;
		}
		if (curr.left == null) {
			if (curr == prev.left)
				prev.left = curr.right;
			else {
				prev.right = curr.right;
				return true;
			}
		} else {
			TreeNode maximumNode = curr.left;
			while (maximumNode.right != null) {
				maximumNode = maximumNode.right;
			}
			E temp = maximumNode.data;
			remove(temp);
			curr.data = temp;
			return true;
		}
		return true;
	}
//this will go through and remove a node if it is there
	public boolean remove(E element) {
		// TODO
		if (root == null)
			return false;
		else if (root.data.equals(element) && root.left == null) {
			root = root.right;
			return true;
		} else if (contains(element) == true) {
			TreeNode curr = root;
			TreeNode prev = root;
			return removeHelper(element, curr, prev);
		}
		return false;
	}
}
