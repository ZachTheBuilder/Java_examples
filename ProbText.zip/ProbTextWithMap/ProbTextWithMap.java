
//Zachariah Rosson
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class ProbTextWithMap {

	public static void main(String[] args) {
		ProbTextWithMap rw = new ProbTextWithMap("Alice", 5);
		System.out.println("Print 500 random letters using an OrderedMap");
		System.out.println("==========================================");
		rw.printRandom(500);
	}

	private OrderedMap<String, ArrayList<Character>> all;
	private int seedLength;
	private String fileName;
	private StringBuilder allTheText;
	private static Random generator;
	private String nGram;

	public ProbTextWithMap(String fileName, int seedLength) {
		this.fileName = fileName;
		this.seedLength = seedLength;
		generator = new Random();
		makeTheText();
		nGram = randomNGram();
		// setUpMap(); // Algorithm considered during lab
	}

	// read from the OrderedMap
	public void makeTheText() {
		if (all != null) {
			String word = all.get(nGram).toString();
			allTheText.append(word);
		}
	}

	// find a random spot in the stringbuilder
	public String randomNGram() {
		int randNum = generator.nextInt(allTheText.length() - seedLength);
		String newNGram = allTheText.substring(randNum, randNum + seedLength);
		return newNGram;
	}

	// Print n characters using a probabalistic text generation scheme
	public void printRandom(int n) {
		if(n < 12){
			System.out.print(nGram);
			n++;
			printRandom(n);
		}
		else{
			System.out.println("");
			printRandom(0);
		}
	}
}