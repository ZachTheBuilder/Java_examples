import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*author zach rosson
 * 
 */

public class Boggle {

	private int score;
	private ArrayList<String> guesses;
	private ArrayList<String> wordList;
	private ArrayList<String> foundList;
	private String fileName = "BoggleWords";

	// Boggle will use your well-tested BoggleTray.
	private BoggleTray boggleTray;

	// Other instance variables will be needed to store collections such
	// as the 80,000+ BoggleWords ...

	// Initialize a new game. Random dice not needed until part 3
	public Boggle() {
		// TODO: Complete this method
		guesses = new ArrayList<String>();
		boggleTray = new BoggleTray();

	}

	// Allow testers to set the BoggleTray to a known one (not random).
	public void setBoggleTray(BoggleTray dt) {
		boggleTray = dt;
	}

	// Return the BoggleTray object as a textual representation as a String
	public String getBoggleTrayAsString() {
		return boggleTray.toString();
	}

	// Record one word (a string with no whitespace) as one of the users'
	// guesses.
	// Do what you want with it, but oneGuess should be processed so all methods
	// can return the correct values such as getScore() and getWordsFound().
	public void addGuess(String oneGuess) {
		score = 0;
		// do not add duplicate guesses
		if (!guesses.contains(oneGuess)) {
			guesses.add(oneGuess);
		}
		// always update correct guesses and score
		getWordsFound();
	}

	// Return a list of all words the user entered that count for the score. The
	// found words
	// must be in their natural ordering. This method should return an empty
	// list until
	// addGuess(String) is called at least once. The returned List<E> could also
	// be empty if
	// no attempts actually counted for anything. There must be no duplicates!
	public List<String> getWordsFound() {
		ArrayList<String> correctGuesses;
		correctGuesses = new ArrayList<String>();

		for (String str : guesses) {
			if (boggleTray.foundInBoggleTray(str)) {
				if (str.length() == 3 || str.length() == 4) {
					score++;
				} else if (str.length() == 5) {
					score += 2;
				} else if (str.length() == 6) {
					score += 3;
				} else if (str.length() == 7) {
					score += 5;
				} else if (str.length() >= 8) {
					score += 11;
				}
				correctGuesses.add(str.toLowerCase());
			}
		}
		Collections.sort(correctGuesses);
		return correctGuesses;
	}

	// Return a list of all words the user entered that do not count for the
	// score
	// in their natural order. This list may be empty with no words guessed or
	// all
	// guessed words actually count for points. There must be no duplicates!
	public List<String> getWordsIncorrect() {
		ArrayList<String> wrongGuesses = new ArrayList<String>();

		for (String str : guesses) {
			str = str.toLowerCase();
			if (!boggleTray.foundInBoggleTray(str)) {
				wrongGuesses.add(str);
			}
		}
		Collections.sort(wrongGuesses);
		return wrongGuesses;
	}

	// All words the user could have guessed but didn't in their natural order.
	// This list could also be empty at first or if the user guessed ALL words
	// in the board and in the list of 80K words (unlikely).
	// There must be no duplicates!
	public List<String> getWordsNotGuessed() {
		ArrayList<String> wordsNotGuessed = new ArrayList<String>();
		populateWordList();

		for (String guess : guesses) {
			if (foundList.contains(guess.toLowerCase())) {
				foundList.remove(guess);
			}
		}

		return foundList;
	}

	@SuppressWarnings("resource")
	private List<String> populateWordList() {
		foundList = new ArrayList<String>();
		wordList = new ArrayList<String>();
		try {
			File inFile = new File(fileName);
			Scanner scanner = new Scanner(inFile);

			while (scanner.hasNext()) {
				String word = scanner.next();
				wordList.add(word.toLowerCase());
				if (boggleTray.foundInBoggleTray(word)) {
					foundList.add(word);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		//inFile.close();
		return foundList;

	}

	// Return the correct score.
	public int getScore() {
		return score;
	}

	/**
	 * The program plays a console based game of Boggle where user type in words
	 * found in the the displayed BoggleTray of BoggleGame.
	 *
	 * @author mercer
	 * @throws IOException
	 *
	 */
	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {

		Boggle game = new Boggle();
		Scanner scanner = new Scanner(System.in);

		System.out.println("Play one game of Boggle:");
		System.out.println(game.boggleTray.toString());
		System.out.println("Enter words or ZZ to quit:");
		String input = "";
		while (scanner.hasNext()) {
			input = scanner.next();
			if (input.equals("zz") || input.equals("ZZ")) {
				break;
			}
			game.addGuess(input);
		}

		System.out.println("\nYour score: " + game.getScore());
		System.out.println("\nWords you found:");

		int newline = 0;
		for (String word : game.getWordsFound()) {
			if (newline > 10) {
				System.out.print("\n");
				newline = 0;
			} else {
				System.out.print(word + " ");
				newline++;
			}
		}
		System.out.println("\n\nIncorrect words:");
		int newlineIncorrect = 0;
		for (String word : game.getWordsIncorrect()) {
			if (newlineIncorrect > 10) {
				System.out.print("\n");
				newlineIncorrect = 0;
			} else {
				System.out.print(word + " ");
				newlineIncorrect++;
			}
		}
		System.out.println("\n\nYou could have found " + game.foundList.size() + " more words.\n"
				+ "The computer found all of your words plus these:\n");
		int newlineAll = 0;
		for (String word : game.foundList) {
			if (newlineAll > 10) {
				System.out.print("\n");
				newlineAll = 0;
			} else {
				System.out.print(word + " ");
				newlineAll++;
			}
		}
	}

	public void printList(ArrayList<String> list) {
		int newline = 0;
		for (String word : list) {
			if (newline > 10) {
				System.out.print("\n");
				newline = 0;
			} else {
				System.out.print(word + " ");
				newline++;
			}
		}
	}

}
