

import java.util.Random;

/**
 * Model the tray of dice in the game Boggle. A DiceTray can be constructed with
 * a 4x4 array of characters for testing. A 2nd constructor with no arguments
 * simulates the shaking of 16 dice and selection of one of the 6 sides.
 * 
 * @author Rick Mercer and Zach Rosson
 */

public class BoggleTray {

	/**
	 * TODO: Construct a tray of dice by simulating the actual Boggle "roll" of
	 * the 16 Boggle dice. This means you will also have to model the 16 dice:
	 * 
	 * @param newBoard
	 *            The 2D array of characters used in testing
	 */
	public BoggleTray() {
		board = new char[SIZE][SIZE];
		path = new char[SIZE][SIZE];
		Random rand = new Random();
		char[][] dice = { { 'L', 'R', 'Y', 'T', 'T', 'E' }, { 'V', 'T', 'H', 'R', 'W', 'E' },
				{ 'E', 'G', 'H', 'W', 'N', 'E' }, { 'S', 'E', 'O', 'T', 'I', 'S' }, { 'A', 'N', 'A', 'E', 'E', 'G' },
				{ 'I', 'D', 'S', 'Y', 'T', 'T' }, { 'O', 'A', 'T', 'T', 'O', 'W' }, { 'M', 'T', 'O', 'I', 'C', 'U' },
				{ 'A', 'F', 'P', 'K', 'F', 'S' }, { 'X', 'L', 'D', 'E', 'R', 'I' }, { 'H', 'C', 'P', 'O', 'A', 'S' },
				{ 'E', 'N', 'S', 'I', 'E', 'U' }, { 'Y', 'L', 'D', 'E', 'V', 'R' }, { 'Z', 'N', 'R', 'N', 'H', 'L' },
				{ 'N', 'M', 'I', 'H', 'U', 'Q' }, { 'O', 'B', 'B', 'A', 'O', 'J' } };

		for (int r = 0; r < SIZE; r++) {
			for (int c = 0; c < SIZE; c++) {
				int rand_i = rand.nextInt(SIZE * SIZE);
				int rand_j = rand.nextInt(NUMBER_SIDES);
				board[r][c] = dice[rand_i][rand_j];
			}
		}
		toString();
	}

	private char[][] path;
	private char[][] board;
	public static final char TRIED = '@';
	public static final char PART_OF_WORD = '!';
	private String attempt;
	public static final int SIZE = 4;
	public static final int NUMBER_SIDES = 6;
	@SuppressWarnings("unused")
	private String pathString = "";
	private int index;

	/**
	 * Construct a tray of dice using a hard coded 2D array of chars. Use this
	 * for testing
	 * 
	 * @param newBoard
	 *            The 2D array of characters used in testing
	 */
	public BoggleTray(char[][] newBoard) {
		board = newBoard;
	}

	/**
	 * Provide a textual version of this BoggleTray
	 */
	@Override
	public String toString() {
		String result = "\n";
		for (int r = 0; r < SIZE; r++) {
			for (int c = 0; c < SIZE; c++) {
				if (board[r][c] == 'Q')
					result += " Qu";
				else
					result += "  " + board[r][c];
			}
			result += " \n\n";
		}
		return result;
	}

	public String pathToString() {
		String result = "\n";
		for (int r = 0; r < SIZE; r++) {
			for (int c = 0; c < SIZE; c++) {
				if (board[r][c] == 'Q')
					result += " Qu";
				else
					result += "  " + path[r][c];
			}
			result += " \n\n";
		}
		return result;
	}

	/**
	 * Return true if search is word that can found on the board following the
	 * rules of Boggle
	 * 
	 * @param str
	 *            A word that may be in the board by connecting consecutive
	 *            letters
	 * 
	 * @return True if str is found in the tray according to the rules of Boggle
	 */
	public boolean foundInBoggleTray(String str) {
		if (str.length() < 3)
			return false;
		attempt = str.toUpperCase().trim();
		boolean found = false;
		for (int r = 0; r < SIZE; r++) {
			for (int c = 0; c < SIZE; c++)
				if (board[r][c] == attempt.charAt(0)) {
					// Set up another 2d array to mark tried spots
					initializeTriedLocations();
					// Use recursive backtracking to find word in the tray
					found = recursiveSearch(r, c);
					// Make sure you don't return false because the word may
					// begin in a later spot
					// In other words, do not return false if a first search
					// fails

					if (found) {
						return true;
					}
				}
		}
		return false;
	}

	// Keep a 2nd 2D array to remember the characters that have been tried
	private void initializeTriedLocations() {
		path = new char[SIZE][SIZE];
		for (int r = 0; r < SIZE; r++)
			for (int c = 0; c < SIZE; c++)
				path[r][c] = '.';
	}

	// private boolean found;

	// This is like the Obstacle course escape algorithm. Now you need to
	// checking eight possible directions instead of only four.
	//
	// WrapAround is not required.
	//
	// Hint: Treat 'Qu' as the char 'Q' somehow.
	//
	private boolean recursiveSearch(int row, int column) {

		index = 0;
		boolean returnBool = recursiveSearch2(row, column);
		return returnBool;
	}

	private boolean recursiveSearch2(int row, int col) {
		boolean found = false;
		// check if row/col is out of bounds
		if (row >= board.length || row < 0 || col >= board[0].length || col < 0 || path[row][col] == TRIED
				|| attempt.charAt(index) != (board[row][col])) {
			return false;
		}
		if (attempt.charAt(index) == 'Q') {
			index += 1;
		}
		path[row][col] = TRIED;
		index++;

		if (index >= attempt.length()) {
			return true;
		}

		if (!found) {
			found = recursiveSearch2(row - 1, col - 1);
		}
		if (!found) {
			found = recursiveSearch2(row - 1, col);
		}
		if (!found) {
			found = recursiveSearch2(row - 1, col + 1);
		}
		if (!found) {
			found = recursiveSearch2(row, col + 1);
		}
		if (!found) {
			found = recursiveSearch2(row + 1, col + 1);
		}
		if (!found) {
			found = recursiveSearch2(row + 1, col);
		}
		if (!found) {
			found = recursiveSearch2(row + 1, col - 1);
		}
		if (!found) {
			found = recursiveSearch2(row, col - 1);
		}

		// mark it part of word if found
		if (found) {
			path[row][col] = PART_OF_WORD;
		} else { // not found, put '.' back and move index back
			path[row][col] = '.';
			index--;
		}
		return found;

	}

}
