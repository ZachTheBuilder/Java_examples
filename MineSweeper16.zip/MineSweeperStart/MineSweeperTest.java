
/**
 * The beginning of a unit test for MineSweeper. 
 * Author Zachariah Rosson 
 */
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class MineSweeperTest {

	@Test
	public void testGetAdjacentMinesWithAGivenTwodArrayOfBooleans() {

		boolean[][] b1 =

		{ { false, false, false, false, false }, { false, false, true, true, false },
				{ false, false, false, true, false }, };

		// Use the non-random constructor when testing to avoid random mine
		// placement.
		MineSweeper ms = new MineSweeper(b1);

		// Check adjacent mines around every possible GameSquare
		assertEquals(0, ms.getAdjacentMines(0, 0));
		assertEquals(1, ms.getAdjacentMines(0, 1));
		assertEquals(2, ms.getAdjacentMines(0, 2));
		assertEquals(2, ms.getAdjacentMines(0, 3));
		assertEquals(1, ms.getAdjacentMines(0, 4));

		assertEquals(0, ms.getAdjacentMines(1, 0));
		assertEquals(1, ms.getAdjacentMines(1, 1));
		assertEquals(2, ms.getAdjacentMines(1, 2)); // works even if it is a
													// mine
		assertEquals(2, ms.getAdjacentMines(1, 3));
		assertEquals(2, ms.getAdjacentMines(1, 4));

		assertEquals(0, ms.getAdjacentMines(2, 0));
		assertEquals(1, ms.getAdjacentMines(2, 1));
		assertEquals(3, ms.getAdjacentMines(2, 2));
		assertEquals(2, ms.getAdjacentMines(2, 3));
		assertEquals(2, ms.getAdjacentMines(2, 4));
	}

	// test to see if it can check how many mines there are
	@Test
	public void testGetTotalMineCount() {

		boolean[][] b1 =

		{ { false, false, false, false, false }, { false, false, true, true, false },
				{ false, false, false, true, false }, };

		// Use the non-random constructor when testing to avoid random mine
		// placement.
		MineSweeper ms = new MineSweeper(b1);

		assertEquals(3, ms.getTotalMineCount());
	}

	// test to see if is mine says a mine is a mine
	@Test
	public void testIsMine() {

		boolean[][] b1 =

		{ { false, false, false, false, false }, { false, false, true, true, false },
				{ false, false, false, true, false }, };

		// Use the non-random constructor when testing to avoid random mine
		// placement.
		MineSweeper ms = new MineSweeper(b1);

		assertFalse(ms.isMine(0, 0));
		assertTrue(ms.isMine(1, 2));
		assertFalse(ms.isMine(2, 4));
	}

	// test to see if is mine says a mine is a mine
	@Test
	public void testIsFlagged() {

		boolean[][] b1 =

		{ { false, false, false, false, false }, { false, false, true, true, false },
				{ false, false, false, true, false }, };

		// Use the non-random constructor when testing to avoid random mine
		// placement.
		MineSweeper ms = new MineSweeper(b1);

		assertFalse(ms.isFlagged(0, 0));
		assertFalse(ms.isFlagged(1, 3));
		assertFalse(ms.isFlagged(2, 2));
		assertFalse(ms.isFlagged(1, 1));
		ms.isFlagged(1, 2);
		assertTrue(ms.isMine(1, 2));

	}

	// test is it toggles between true flase flags
	@Test
	public void testToggleFlagged() {

		boolean[][] b1 =

		{ { false, false, false, false, false }, { false, false, true, true, false },
				{ false, false, false, true, false }, };

		// Use the non-random constructor when testing to avoid random mine
		// placement.
		MineSweeper ms = new MineSweeper(b1);

		assertFalse(ms.isFlagged(1, 2));
		ms.isFlagged(1, 2);
		assertTrue(ms.isMine(1, 2));
		ms.isFlagged(1, 2);
		assertFalse(ms.isFlagged(1, 2));
	}

	@Test
	public void testIsVisible() {

		boolean[][] b1 =

		{ { false, false, false, false, false }, { false, false, true, true, false },
				{ false, false, false, true, false }, };

		// Use the non-random constructor when testing to avoid random mine
		// placement.
		MineSweeper ms = new MineSweeper(b1);

		assertFalse(ms.isVisible(1, 2));
	}

	@Test
	public void testToString() {

		boolean[][] b1 =

		{ { false, false, false, false, false }, { false, false, true, true, false },
				{ false, false, false, true, false }, };

		// Use the non-random constructor when testing to avoid random mine
		// placement.
		MineSweeper ms = new MineSweeper(b1);

		assertEquals("Under construction", ms.toString().trim());
	}
}